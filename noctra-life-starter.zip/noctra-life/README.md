# NOCTRA LIFE — free starter

A mobile-first, installable web-app prototype. No paid service or API key is required.

## Run locally
Open `index.html` in a modern browser. Most features work locally. To test install/offline support, serve this folder over HTTPS or localhost.

## Publish free
1. Create a free GitHub account if you don't have one.
2. Create a public repository named `noctra-life`.
3. Upload the files in this folder to the repository root.
4. In GitHub, open **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for the Pages URL to appear. Open it on your phone and use **Add to Home Screen** / **Install app**.

## Important prototype limits
- Data and attachments are stored only in the current browser on the current device.
- There is no account, cloud sync, server backup, or secure private document vault yet.
- Attachments are limited to 10 MB each and stored as browser data; avoid sensitive identity, banking, or medical documents.
- Browser notifications are not scheduled reliably in the background. The reminders list is available when you open the app.
- No AI extraction or paid billing is included.
- Export JSON/CSV regularly. Clearing browser data may erase records and files.

## Next production steps
Move user data to a properly secured backend with authentication, row-level access controls, private object storage, server-side reminder scheduling, and tested export/deletion flows before inviting users to store sensitive documents.
